export async function exportToGoogleSheets(leads: any[], accessToken: string) {
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: `ProspectPilot Leads - ${new Date().toISOString().split('T')[0]}`
      }
    })
  });

  if (!createRes.ok) throw new Error("Failed to create spreadsheet");
  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;

  const values = [
    ['Name', 'Website', 'Address', 'Email', 'Status', 'Audit Score', 'Audit Detail', 'Cold Email Draft', 'Decision Maker', 'Title', 'DM Email', 'DM Phone', 'LinkedIn'],
    ...leads.map(lead => [
      lead.name || '',
      lead.website || '',
      lead.address || '',
      lead.foundEmail || '',
      lead.status || '',
      lead.auditScore || '',
      lead.auditDetail || '',
      lead.coldEmail || '',
      lead.decisionMakerName || '',
      lead.decisionMakerTitle || '',
      lead.decisionMakerEmail || '',
      lead.decisionMakerPhone || '',
      lead.decisionMakerLinkedin || ''
    ])
  ];

  const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      values
    })
  });

  if (!appendRes.ok) throw new Error("Failed to append data");
  return sheetData.spreadsheetUrl;
}
