/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Play, CheckCircle2, XCircle, MapPin, Globe,
  Mail, Settings, ChevronRight, Copy, Check, Info, AlertTriangle, X, Download
} from 'lucide-react';
import { US_CITIES, NICHES } from './lib/constants';
import { cn } from './lib/utils';

type ToastType = 'error' | 'success' | 'info' | 'warning';
type ToastMsg = {
  id: string;
  message: string;
  type: ToastType;
};

type Lead = {
  id: string;
  name: string;
  website: string;
  address: string;
  status: 'pending' | 'extracting' | 'capturing' | 'auditing' | 'drafting' | 'completed' | 'error';
  foundEmail?: string | null;
  auditScore?: number;
  auditDetail?: string;
  coldEmail?: string;
  decisionMakerName?: string | null;
  decisionMakerTitle?: string | null;
  decisionMakerEmail?: string | null;
  decisionMakerPhone?: string | null;
  decisionMakerLinkedin?: string | null;
};

import { initAuth, googleSignIn, getAccessToken } from './lib/auth';
import { exportToGoogleSheets } from './lib/sheets';

export default function App() {
  const [selectedCity, setSelectedCity] = useState(US_CITIES[0].city);
  const [selectedState, setSelectedState] = useState(US_CITIES[0].state);
  const [selectedNiche, setSelectedNiche] = useState(NICHES[0].id);
  
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  type RecentSearch = { city: string; state: string; niche: string; timestamp: number };
  const [recentSearches, setRecentSearches] = useState<RecentSearch[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("prospectPilotRecent") || "[]");
    } catch {
      return [];
    }
  });
  const [selectedLeads, setSelectedLeads] = useState<Set<number>>(new Set());
  const [exportedHistory, setExportedHistory] = useState<Record<string, { timestamp: number }>>(() => {
    try {
      return JSON.parse(localStorage.getItem("prospectPilotExported") || "{}");
    } catch {
      return {};
    }
  });

  const [processedHistory, setProcessedHistory] = useState<Record<string, { timestamp: number }>>(() => {
    try {
      return JSON.parse(localStorage.getItem("prospectPilotHistory") || "{}");
    } catch {
      return {};
    }
  });
  const [googleAuthStatus, setGoogleAuthStatus] = useState<"idle" | "authorizing" | "exporting" | "success" | "error">("idle");
  const [sheetUrl, setSheetUrl] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<string>('');
  
  const [toasts, setToasts] = useState<ToastMsg[]>([]);

  useEffect(() => {
    initAuth();
  }, []);

  const addToast = (message: string, type: ToastType = 'error') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => removeToast(id), 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Update readonly state based on selected city
  useEffect(() => {
    const cityData = US_CITIES.find(c => c.city === selectedCity);
    if (cityData) {
      setSelectedState(cityData.state);
    }
  }, [selectedCity]);

  const handleSearch = async () => {
    setIsSearching(true);
    setLeads([]);
    setSelectedLeads(new Set());
    setCurrentStep('Scraping...');
    
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          city: selectedCity,
          state: selectedState,
          niche: selectedNiche,
        })
      });
      
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to search');
      }
      
      const mappedLeads: Lead[] = data.leads.map((l: any) => ({
        ...l,
        status: 'pending'
      }));
      
      setLeads(mappedLeads);
      setCurrentStep(`Found ${mappedLeads.length} leads.`);
      
      setRecentSearches(prev => {
        const newSearch = { city: selectedCity, state: selectedState, niche: selectedNiche, timestamp: Date.now() };
        const filtered = prev.filter(s => !(s.city === newSearch.city && s.state === newSearch.state && s.niche === newSearch.niche));
        const updated = [newSearch, ...filtered].slice(0, 5);
        localStorage.setItem("prospectPilotRecent", JSON.stringify(updated));
        return updated;
      });
      if (mappedLeads.length === 0) {
        addToast('No leads found for this location and niche.', 'info');
      } else {
        addToast(`Found ${mappedLeads.length} leads successfully.`, 'success');
      }
    } catch (err: any) {
      addToast(err.message, 'error');
      setCurrentStep('');
    } finally {
      setIsSearching(false);
    }
  };

  const processLead = async (leadIndex: number) => {
    // 1. Extract Email
    updateLead(leadIndex, { status: 'extracting' });
    setCurrentStep('Extracting Contact Info...');
    
    let foundEmail = null;
    try {
      const emailRes = await fetch('/api/scrape-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ website: leads[leadIndex].website })
      });
      if (emailRes.ok) {
        const body = await emailRes.json();
        foundEmail = body.email;
      }
    } catch (e) {
      // safe fallback
    }
    
    updateLead(leadIndex, { foundEmail, status: 'capturing' });
    setCurrentStep('Capturing Screenshots...');
    
    // 2. Audit & Draft (done by Gemini together)
    updateLead(leadIndex, { status: 'auditing' });
    setCurrentStep('Auditing & Drafting...');
    
    try {
      const auditRes = await fetch('/api/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          website: leads[leadIndex].website,
          name: leads[leadIndex].name,
          city: selectedCity,
          state: selectedState
        })
      });
      const auditData = await auditRes.json();
      if (!auditRes.ok) {
        addToast(`Audit failed for ${leads[leadIndex].name}: ${auditData.error || 'Unknown error'}`, 'warning');
        throw new Error(auditData.error || 'Audit failed');
      }
      
      updateLead(leadIndex, {
        status: 'completed',
        auditScore: auditData.auditScore,
        auditDetail: auditData.auditDetail,
        coldEmail: auditData.coldEmail,
        decisionMakerName: auditData.decisionMakerName,
        decisionMakerTitle: auditData.decisionMakerTitle,
        decisionMakerEmail: auditData.decisionMakerEmail,
        decisionMakerPhone: auditData.decisionMakerPhone,
        decisionMakerLinkedin: auditData.decisionMakerLinkedin,
      });
    } catch (err) {
      updateLead(leadIndex, { status: 'error' });
    }
  };

  const startPipeline = async () => {
    const leadsToProcess = selectedLeads.size > 0 
      ? leads.map((_, i) => i).filter(i => selectedLeads.has(i))
      : leads.map((_, i) => i).filter(i => leads[i].status === 'pending');

    if (leadsToProcess.length === 0) return;
    setIsProcessing(true);
    
    for (const i of leadsToProcess) {
        if (leads[i].status === 'pending') {
            await processLead(i);
        }
    }
    
    setCurrentStep('Pipeline Finished');
    setIsProcessing(false);
    setSelectedLeads(new Set());
    addToast('Finished processing selected leads.', 'success');
  };

  const exportToCsv = () => {
    const leadsToExport = selectedLeads.size > 0 
      ? leads.filter((_, i) => selectedLeads.has(i))
      : leads;
    if (leadsToExport.length === 0) return;
    
    const headers = ['Name', 'Website', 'Address', 'Email', 'Status', 'Audit Score', 'Audit Detail', 'Cold Email Draft'];
    
    const csvContent = [
      headers.join(','),
      ...leadsToExport.map(lead => {
        return [
          `"${lead.name?.replace(/"/g, '""') || ''}"`,
          `"${lead.website?.replace(/"/g, '""') || ''}"`,
          `"${lead.address?.replace(/"/g, '""') || ''}"`,
          `"${lead.foundEmail?.replace(/"/g, '""') || ''}"`,
          `"${lead.status}"`,
          `"${lead.auditScore !== undefined ? lead.auditScore : ''}"`,
          `"${lead.auditDetail?.replace(/"/g, '""') || ''}"`,
          `"${lead.coldEmail?.replace(/"/g, '""') || ''}"`
        ].join(',');
      })
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `prospect_pilot_leads_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportedHistory(prev => {
      const copy = { ...prev };
      leadsToExport.forEach(lead => {
        copy[lead.website] = { timestamp: Date.now() };
      });
      localStorage.setItem("prospectPilotExported", JSON.stringify(copy));
      return copy;
    });
    setSelectedLeads(new Set());
    addToast('Exported CSV successfully', 'success');
  };

  const handleGoogleSheetsExport = async () => {
    const leadsToExport = selectedLeads.size > 0 
      ? leads.filter((_, i) => selectedLeads.has(i))
      : leads;
    if (leadsToExport.length === 0) return;

    try {
      setIsExporting(true);
      setGoogleAuthStatus('authorizing');
      let token = await getAccessToken();
      if (!token) {
        const authRes = await googleSignIn();
        if (authRes) token = authRes.accessToken;
      }
      if (token) {
        setGoogleAuthStatus('exporting');
        addToast('Exporting to Google Sheets...', 'info');
        const url = await exportToGoogleSheets(leadsToExport, token);
        setSheetUrl(url);
        setGoogleAuthStatus('success');

        setExportedHistory(prev => {
          const copy = { ...prev };
          leadsToExport.forEach(lead => {
            copy[lead.website] = { timestamp: Date.now() };
          });
          localStorage.setItem("prospectPilotExported", JSON.stringify(copy));
          return copy;
        });
        setSelectedLeads(new Set());

        addToast(`Exported successfully! Check your Google Sheets.`, 'success');
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.rel = 'noreferrer';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    } catch (err: any) {
      setGoogleAuthStatus('error');
      addToast(`Export failed: ${err.message}`, 'error');
    } finally {
      setIsExporting(false);
      setTimeout(() => setGoogleAuthStatus('idle'), 5000);
    }
  };

  const updateLead = (index: number, updates: Partial<Lead>) => {
    setLeads(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], ...updates };
      return copy;
    });
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans selection:bg-indigo-500/30 selection:text-indigo-200 pb-20 relative">
      
      {/* Toast Container */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none w-full max-w-sm">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
              className={cn(
                "pointer-events-auto flex items-start gap-3 p-4 rounded-xl shadow-lg border backdrop-blur-md transition-colors",
                t.type === 'error' ? 'bg-red-500/10 border-red-500/20 text-red-200' :
                t.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-200' :
                t.type === 'warning' ? 'bg-amber-500/10 border-amber-500/20 text-amber-200' :
                'bg-slate-800/80 border-white/10 text-slate-200'
              )}
            >
              <div className="mt-0.5 shrink-0">
                {t.type === 'error' && <XCircle size={18} className="text-red-400" />}
                {t.type === 'success' && <CheckCircle2 size={18} className="text-emerald-400" />}
                {t.type === 'warning' && <AlertTriangle size={18} className="text-amber-400" />}
                {t.type === 'info' && <Info size={18} className="text-blue-400" />}
              </div>
              <p className="text-sm font-medium leading-relaxed flex-1">{t.message}</p>
              <button 
                onClick={() => removeToast(t.id)} 
                className="shrink-0 p-1 rounded-md opacity-50 hover:opacity-100 transition-opacity hover:bg-white/10"
              >
                <X size={14} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Header */}
      <header className="border-b border-white/5 bg-slate-900/50 backdrop-blur-md sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-500 text-white rounded p-1.5 flex items-center justify-center">
              <MapPin size={20} strokeWidth={2.5} />
            </div>
            <h1 className="text-xl font-semibold tracking-tight text-white">ProspectPilot</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Sidebar: Controls */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-800 rounded-xl p-6 border border-white/5 shadow-xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent pointer-events-none" />
            
            <h2 className="text-lg font-medium text-slate-100 mb-4 flex items-center gap-2">
              <Search size={18} className="text-indigo-400" />
              Search Leads
            </h2>
            
            <div className="space-y-4 relative">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wider">City</label>
                <select 
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all appearance-none"
                  value={selectedCity}
                  onChange={e => setSelectedCity(e.target.value)}
                  disabled={isSearching || isProcessing}
                >
                  {US_CITIES.map(c => (
                    <option key={c.city} value={c.city}>{c.city}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wider">State</label>
                <input 
                  type="text"
                  readOnly
                  disabled
                  value={selectedState}
                  className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-400 cursor-not-allowed opacity-70"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wider">Niche</label>
                <select 
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all appearance-none"
                  value={selectedNiche}
                  onChange={e => setSelectedNiche(e.target.value)}
                  disabled={isSearching || isProcessing}
                >
                  {NICHES.map(n => (
                    <option key={n.id} value={n.id}>{n.name}</option>
                  ))}
                </select>
              </div>

              <button 
                onClick={handleSearch}
                disabled={isSearching || isProcessing}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium text-sm rounded-lg py-2.5 transition-colors flex items-center justify-center gap-2 mt-4"
              >
                {isSearching ? (
                  <div className="h-4 w-4 rounded-full border-2 border-white/20 border-t-white animate-spin" />
                ) : (
                  <Search size={16} />
                )}
                Find Leads
              </button>
            </div>
          </div>

          {recentSearches.length > 0 && (
            <div className="bg-slate-800 rounded-xl p-6 border border-white/5 shadow-xl">
              <h3 className="text-sm font-medium text-slate-200 mb-3 flex items-center gap-2">
                <svg className="w-4 h-4 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                Recent Searches
              </h3>
              <div className="space-y-2">
                {recentSearches.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setSelectedCity(s.city);
                      setSelectedState(s.state);
                      setSelectedNiche(s.niche);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg bg-slate-900/50 hover:bg-slate-700 transition-colors border border-slate-700/50 text-sm flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-medium text-slate-200">{s.city}, {s.state}</div>
                      <div className="text-xs text-slate-400">{NICHES.find(n => n.id === s.niche)?.name || s.niche}</div>
                    </div>
                    <Search size={14} className="text-slate-500 group-hover:text-indigo-400 transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {(leads.length > 0) && (
             <div className="bg-slate-800 rounded-xl p-6 border border-white/5 shadow-xl">
               <h3 className="text-sm font-medium text-slate-200 mb-2">Processing Pipeline</h3>
               <div className="flex items-center justify-between text-xs text-slate-400 mb-4 bg-slate-900 rounded p-3">
                 <span className="truncate mr-2">Status: {currentStep || 'Idle'}</span>
                 {isProcessing && <div className="h-3 w-3 rounded-full bg-indigo-500 animate-pulse shrink-0" />}
               </div>
               
               <div className="flex flex-col gap-2">
                 <button
                   onClick={startPipeline}
                   disabled={isProcessing || isSearching}
                   className="w-full bg-slate-700 hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium text-sm rounded-lg py-2.5 transition-colors flex items-center justify-center gap-2"
                 >
                   <Play size={16} className={cn(isProcessing && "opacity-50")} />
                   {isProcessing ? 'Processing Sequentially...' : (selectedLeads.size > 0 ? `Bulk Process (${selectedLeads.size})` : 'Start Pipeline')}
                 </button>
                 <div className="grid grid-cols-2 gap-2">
                   <button
                     onClick={exportToCsv}
                     disabled={leads.length === 0}
                     className="w-full bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-300 disabled:opacity-50 disabled:cursor-not-allowed font-medium text-sm rounded-lg py-2 transition-colors flex items-center justify-center gap-2"
                   >
                     <Download size={16} />
                     {selectedLeads.size > 0 ? `CSV (${selectedLeads.size})` : 'CSV'}
                   </button>
                   <button
                     onClick={handleGoogleSheetsExport}
                     disabled={leads.length === 0 || isExporting}
                     className="w-full bg-[#188038] hover:bg-[#146c2e] text-white disabled:opacity-50 disabled:cursor-not-allowed font-medium text-sm rounded-lg py-2 transition-colors flex items-center justify-center gap-2"
                   >
                     {isExporting ? <div className="h-4 w-4 rounded-full border-2 border-white/20 border-t-white animate-spin" /> : <Download size={16} />}
                     {selectedLeads.size > 0 ? `Sheets (${selectedLeads.size})` : 'Google Sheets'}
                   </button>
                 </div>
                 {sheetUrl && (
                   <div className="mt-3 text-center">
                     <a
                       href={sheetUrl}
                       target="_blank"
                       rel="noreferrer"
                       className="text-xs font-medium text-[#188038] hover:text-[#146c2e] underline transition-colors"
                     >
                       Open Google Sheet ↗
                     </a>
                   </div>
                 )}
               </div>
             </div>
          )}
        </div>

        {/* Right Content: Feed */}
        <div className="lg:col-span-8">
          <div className="flex flex-col gap-4">
            
            {leads.length > 0 && (
              <div className="flex items-center justify-between bg-slate-800/50 rounded-xl px-4 py-3 border border-white/5">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    className="w-4 h-4 rounded border-slate-600 bg-slate-700/50 text-indigo-500 focus:ring-indigo-500/30 cursor-pointer"
                    checked={selectedLeads.size === leads.length && leads.length > 0}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedLeads(new Set(leads.map((_, i) => i)));
                      } else {
                        setSelectedLeads(new Set());
                      }
                    }}
                  />
                  <span className="text-sm font-medium text-slate-300">
                    {selectedLeads.size > 0 ? `${selectedLeads.size} selected` : 'Select All'}
                  </span>
                </div>
              </div>
            )}

            <AnimatePresence>
              {leads.map((lead, index) => (
                <motion.div
                  key={lead.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: Math.min(index * 0.1, 1) }}
                >
                  <LeadCard 
                    lead={lead} 
                    onProcess={() => processLead(index)} 
                    isProcessingApp={isProcessing} 
                    isPreviouslyProcessed={!!processedHistory[lead.website]} 
                    isPreviouslyExported={!!exportedHistory[lead.website]}
                    isSelected={selectedLeads.has(index)}
                    onToggleSelect={() => {
                      const newSet = new Set(selectedLeads);
                      if (newSet.has(index)) newSet.delete(index);
                      else newSet.add(index);
                      setSelectedLeads(newSet);
                    }}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
            
            {leads.length === 0 && !isSearching && (
              <div className="h-[40vh] flex flex-col items-center justify-center text-slate-500 border border-dashed border-slate-700/50 rounded-xl bg-slate-800/30">
                <Globe size={48} strokeWidth={1} className="mb-4 opacity-50" />
                <p>Run a search to populate leads</p>
              </div>
            )}
            {leads.length === 0 && isSearching && (
               <div className="h-[40vh] flex flex-col items-center justify-center text-slate-400">
                 <div className="h-8 w-8 rounded-full border-2 border-indigo-500/30 border-t-indigo-500 animate-spin mb-4" />
                 <p>Scraping local businesses...</p>
               </div>
            )}
          </div>
        </div>

      </main>
    </div>
  );
}

function LeadCard({ lead, onProcess, isProcessingApp, isPreviouslyProcessed, isPreviouslyExported, isSelected, onToggleSelect }: { lead: Lead, onProcess: () => void, isProcessingApp: boolean, isPreviouslyProcessed?: boolean, isPreviouslyExported?: boolean, isSelected?: boolean, onToggleSelect?: () => void }) {
  const [activeTab, setActiveTab] = useState<'audit' | 'email'>('audit');
  
  // Local state for the editable email field
  const [manualEmail, setManualEmail] = useState('');
  
  // Re-populate if foundEmail exists and manualEmail is empty
  useEffect(() => {
    if (lead.foundEmail && !manualEmail) {
      setManualEmail(lead.foundEmail);
    }
  }, [lead.foundEmail, manualEmail]);

  const [copied, setCopied] = useState(false);
  const copyEmail = () => {
    if (lead.foundEmail) {
      navigator.clipboard.writeText(lead.foundEmail);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const isBusy = ['extracting', 'capturing', 'auditing', 'drafting'].includes(lead.status);

  return (
    <div className={cn(
      "bg-slate-800 rounded-xl border shadow-md overflow-hidden flex flex-col text-sm transition-all",
      isSelected ? "border-indigo-500/50" : "border-white/5 hover:border-slate-600/50"
    )}>
      {/* Card Header & Compact Info */}
      <div className="p-5 flex items-start gap-4 flex-col sm:flex-row">
        {onToggleSelect && (
          <div className="pt-0.5 shrink-0">
            <input
              type="checkbox"
              className="w-4 h-4 rounded border-slate-600 bg-slate-700/50 text-indigo-500 focus:ring-indigo-500/30 cursor-pointer"
              checked={isSelected}
              onChange={onToggleSelect}
            />
          </div>
        )}
        
        <div className="flex-1 min-w-0 w-full">
          <div className="flex items-start justify-between mb-1">
             <h3 className="text-base font-semibold text-white">{lead.name}</h3>
             
             {/* Score Badge */}
             <div className="flex flex-wrap items-center gap-2">
               {isPreviouslyProcessed && (
                 <div className="px-2.5 py-0.5 rounded-full text-[10px] font-medium border bg-indigo-500/10 text-indigo-400 border-indigo-500/20 uppercase tracking-wider flex items-center gap-1 shrink-0">
                   <CheckCircle2 size={10} /> Processed
                 </div>
               )}
               {isPreviouslyExported && (
                 <div className="px-2.5 py-0.5 rounded-full text-[10px] font-medium border bg-[#188038]/10 text-[#2eac54] border-[#188038]/20 uppercase tracking-wider flex items-center gap-1 shrink-0">
                   <CheckCircle2 size={10} /> Exported
                 </div>
               )}
               {lead.auditScore !== undefined && (
               <div className={cn(
                 "px-2.5 py-0.5 rounded-full text-xs font-medium border flex items-center gap-1 shrink-0",
                 lead.auditScore > 75 ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" :
                 lead.auditScore >= 50 ? "bg-amber-500/10 text-amber-400 border-amber-500/20" :
                 "bg-rose-500/10 text-rose-400 border-rose-500/20"
               )}>
                 Score: {lead.auditScore}
               </div>
             )}
             </div>
          </div>

          <div className="text-slate-400 text-xs flex flex-col gap-1.5 mt-2">
            <div className="flex items-center gap-1.5 truncate">
               <Globe size={14} className="shrink-0" />
               <a href={lead.website} target="_blank" rel="noreferrer" className="hover:text-indigo-400 hover:underline truncate">{lead.website}</a>
            </div>
            <div className="flex items-center gap-1.5 truncate">
               <MapPin size={14} className="shrink-0" />
               <span className="truncate">{lead.address}</span>
            </div>
            
            {/* Email extracted status */}
            <div className="flex items-center gap-1.5 mt-1 border-t border-slate-700 pt-2">
              <Mail size={14} className="shrink-0 text-slate-500" />
              {lead.foundEmail ? (
                <>
                  <span className="text-emerald-400 truncate">{lead.foundEmail}</span>
                  <button onClick={copyEmail} className="p-1 hover:bg-slate-700 rounded text-slate-400 transition ml-1" title="Copy">
                     {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  </button>
                </>
              ) : lead.status === 'completed' ? (
                <span className="text-amber-500/80 italic">Email needed</span>
              ) : (
                <span className="text-slate-500">Not extracted</span>
              )}
            </div>
          </div>
        </div>

        {/* Action button if pending */}
        <div className="sm:self-center shrink-0 w-full sm:w-auto mt-2 sm:mt-0">
          {lead.status === 'pending' || lead.status === 'error' ? (
             <button 
               onClick={onProcess}
               disabled={isProcessingApp}
               className="w-full sm:w-auto bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white text-xs px-4 py-2 rounded-md transition"
             >
               {lead.status === 'error' ? 'Retry Process' : 'Process'}
             </button>
          ) : lead.status === 'completed' ? (
             <div className="text-emerald-400 flex items-center justify-center gap-1.5 text-xs px-3 py-1.5 bg-emerald-400/10 rounded-full border border-emerald-400/20">
               <CheckCircle2 size={14} /> Done
             </div>
          ) : (
             <div className="flex items-center gap-2 text-indigo-400 text-xs px-3 py-1.5 bg-indigo-400/10 rounded-full border border-indigo-400/20">
               <div className="h-3 w-3 rounded-full border-2 border-indigo-400/30 border-t-indigo-400 animate-spin" />
               <span className="capitalize">{lead.status}...</span>
             </div>
          )}
        </div>
      </div>

      {/* Audit/Draft Details (only shown when completed) */}
      {lead.status === 'completed' && (
        <div className="border-t border-slate-700/50 bg-slate-900/30 flex flex-col">
          <div className="flex border-b border-slate-700/50">
            <button 
              className={cn("flex-1 py-3 text-xs font-medium transition-colors", activeTab === 'audit' ? "text-indigo-400 border-b-2 border-indigo-500" : "text-slate-400 hover:text-slate-300")}
              onClick={() => setActiveTab('audit')}
            >
              System Audit
            </button>
            <button 
              className={cn("flex-1 py-3 text-xs font-medium transition-colors", activeTab === 'email' ? "text-indigo-400 border-b-2 border-indigo-500" : "text-slate-400 hover:text-slate-300")}
              onClick={() => setActiveTab('email')}
            >
              Drafted Email
            </button>
          </div>

          <div className="p-5 text-slate-300 leading-relaxed max-h-64 overflow-y-auto custom-scrollbar">
            {activeTab === 'audit' ? (
              <div className="space-y-4">
                <div>
                   <h4 className="text-slate-500 text-[11px] uppercase tracking-wider mb-1">AI Findings</h4>
                   <p className="text-[13px]">{lead.auditDetail}</p>
                </div>
                {lead.decisionMakerName && (
                <div className="bg-slate-800/50 rounded p-3 border border-slate-700/50">
                   <h4 className="text-slate-500 text-[11px] uppercase tracking-wider mb-2 text-indigo-400">Key Decision Maker</h4>
                   <div className="grid grid-cols-2 gap-y-2 text-[13px]">
                     <span className="text-slate-400">Name:</span>
                     <span className="font-medium text-slate-200">{lead.decisionMakerName}</span>
                     <span className="text-slate-400">Title:</span>
                     <span>{lead.decisionMakerTitle || '-'}</span>
                     <span className="text-slate-400">Email:</span>
                     <span className="text-emerald-400">{lead.decisionMakerEmail || '-'}</span>
                     <span className="text-slate-400">LinkedIn:</span>
                     {lead.decisionMakerLinkedin ? (
                       <a href={lead.decisionMakerLinkedin} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline truncate">View Profile</a>
                     ) : (
                       <span>-</span>
                     )}
                   </div>
                </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                 <div className="flex items-center gap-2">
                    <label className="text-[11px] text-slate-500 uppercase tracking-wider shrink-0 w-16">To:</label>
                    <input 
                      className="flex-1 bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      value={manualEmail}
                      onChange={(e) => setManualEmail(e.target.value)}
                      placeholder="Add an email address..."
                    />
                 </div>
                 <div className="flex items-start gap-2">
                    <label className="text-[11px] text-slate-500 uppercase tracking-wider shrink-0 w-16 pt-1.5">Draft:</label>
                    <textarea 
                      className="flex-1 bg-slate-900 border border-slate-700 rounded px-2.5 py-2 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 min-h-[100px] resize-y custom-scrollbar"
                      defaultValue={lead.coldEmail}
                    />
                 </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

